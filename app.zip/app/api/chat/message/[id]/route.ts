import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/getUser";
import { NextResponse as NextResp } from "next/server"; 

export async function PUT(
  req: Request,
  // 💥 KÖTELEZŐ JAVÍTÁS: Destrukturálás a szignatúrában a Promise hiba elkerülése végett
  { params }: { params: { id: string } }
) {
  try {
    // 1. Kérés body-jának beolvasása
    const body = await req.json();
    const { text } = body; 
    
    // 2. Azonosító kinyerése (a destrukturált 'params'-ból)
    const messageId = params.id;
 // Mappa neve [Id] -> kulcs Id
    
    // Hiba elkapása, ha a kinyerés sikertelen volt
    if (!messageId) {
        return NextResp.json({ error: "Hiányzó üzenetazonosító." }, { status: 400 });
    }
    
    // 3. Validáció és jogosultság ellenőrzése
    if (!text || typeof text !== "string" || text.trim().length === 0) {
        return NextResp.json({ error: "Hiányzó vagy érvénytelen szöveg." }, { status: 400 });
    }

    const user = await getUserFromRequest(req);
    if (!user) {
        return NextResp.json({ error: "Nincs azonosítva" }, { status: 401 });
    }

    // Üzenet keresése
    const msg = await prisma.chatMessage.findUnique({ 
        where: { id: messageId } 
    });

    if (!msg) {
      return NextResp.json({ error: "Üzenet nem található" }, { status: 404 });
    }
    
    // Jogosultság ellenőrzése
    if (msg.authorId !== user.id && user.role === "USER") {
      return NextResp.json({ error: "Nincs jogosultsága a szerkesztéshez" }, { status: 403 });
    }
    
    // 4. Adatbázis frissítése
    const updatedMsg = await prisma.chatMessage.update({ 
      where: { id: messageId },
      data: { 
          text: text.trim(), 
          edited: true, 
      },
    });

    // 5. Válasz
    return NextResp.json({ success: true, message: "Sikeresen szerkesztve", updatedMsg }, { status: 200 });

  } catch (error) { 
    console.error("KRITIKUS HIBA A CHAT ÜZENET SZERKESZTÉSEKOR (PUT):", error);
    return NextResp.json(
      { error: "Belső szerverhiba történt a szerkesztés során." }, 
      { status: 500 }
    );
  }
}

// ---------------------------------------------------------------------------------

export async function DELETE(
  req: Request,
  { params }: { params: { id: string } } 
) {
  try {
    const messageId = params.id; 
    
    if (!messageId) {
      return NextResp.json({ error: "Hiányzó üzenetazonosító." }, { status: 400 });
    }

    const user = await getUserFromRequest(req);
    
    if (!user) {
      return NextResp.json({ error: "Not authenticated" }, { status: 401 });
    }

    const msg = await prisma.chatMessage.findUnique({ where: { id: messageId } });

    if (!msg) {
      return NextResp.json({ error: "Message not found" }, { status: 404 });
    }

    if (msg.authorId !== user.id && user.role === "USER") {
      return NextResp.json({ error: "Forbidden" }, { status: 403 });
    }

    await prisma.chatMessage.delete({ where: { id: messageId } });

    return NextResp.json({ success: true }, { status: 200 });

  } catch (error) {
    console.error("KRITIKUS HIBA A CHAT ÜZENET TÖRLÉSEKOR (DELETE):", error);
    return NextResp.json(
      { error: "Belső szerverhiba történt a törlés során." }, 
      { status: 500 }
    );
  }
}