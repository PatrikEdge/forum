import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/getUser";
import { NextRequest, NextResponse } from "next/server";
import { wssBroadcast } from "@/lib/wsServer";

export async function DELETE(req, { params }: { params: { messageId: string }})
  const user = await getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const msg = await prisma.dMMessage.findUnique({
    where: { id: Number(params.id) }
  });

  if (!msg || msg.fromId !== user.id)
    return NextResponse.json({ error: "No permission" }, { status: 403 });

  await prisma.dMMessage.delete({ where: { id: msg.id } });

  wssBroadcast({ type: "dm_delete", messageId: msg.id });

  return NextResponse.json({ ok: true });
}
