import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/getUser";
import { wssBroadcast } from "@/lib/wsServer";

export async function POST(req: NextRequest) {
  const user = await getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { toId, text, tempId } = await req.json();
  if (!toId || !text?.trim()) return NextResponse.json({ error: "Missing fields" }, { status: 400 });

  const cleanedText = text.trim();

  // ⚠️ Conversation biztosan létezzen
  const a = Math.min(user.id, toId);
  const b = Math.max(user.id, toId);

  await prisma.dMConversation.upsert({
    where: { user1Id_user2Id: { user1Id: a, user2Id: b } },
    update: {},
    create: { user1Id: a, user2Id: b }
  });

  const saved = await prisma.dMMessage.create({
    data: { fromId: user.id, toId, text: cleanedText },
    include: { from: true, to: true }
  });

  const messagePayload = {
    id: saved.id,
    tempId,
    text: saved.text,
    fromId: saved.fromId,
    toId: saved.toId,
    createdAt: saved.createdAt,
    read: saved.read,
    from: { id: saved.from.id, username: saved.from.username, avatarUrl: saved.from.avatarUrl },
    to: { id: saved.to.id, username: saved.to.username, avatarUrl: saved.to.avatarUrl },
  };

  wssBroadcast({ type: "dm_message", message: messagePayload });

  return NextResponse.json({ message: messagePayload });
}
