import { prisma } from "@/lib/prisma";
import { getUserFromRequest } from "@/lib/getUser";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  req: NextRequest,
  { params }: { params: { userId: string } }
) {
  const user = await getUserFromRequest(req);
  if (!user) {
    return NextResponse.json({ messages: [] }, { status: 401 });
  }

  const other = Number(params.userId);

  const messages = await prisma.dMMessage.findMany({
  where: {
    OR: [
      { fromId: user.id, toId: partnerId },
      { fromId: partnerId, toId: user.id }
    ]
  },
  orderBy: { createdAt: "asc" }
});

  return NextResponse.json({ messages });
}